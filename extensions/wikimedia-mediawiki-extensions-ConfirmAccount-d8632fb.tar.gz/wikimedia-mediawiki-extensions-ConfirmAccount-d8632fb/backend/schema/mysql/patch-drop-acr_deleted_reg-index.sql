-- (c) Aaron Schulz, 2013

ALTER TABLE /*_*/account_requests DROP INDEX /*i*/acr_deleted_reg;
